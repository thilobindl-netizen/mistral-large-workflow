"""Workflow: sendet eine Eingabe an Mistral Large 4 und gibt die Antwort zurück."""

from pydantic import BaseModel, Field

import mistralai.workflows as workflows
from mistralai.workflows.plugins.mistralai import (
    ChatCompletionRequest,
    UserMessage,
    mistralai_chat_complete,
)

MODEL = "mistral-large-latest"


class ML4ChatInput(BaseModel):
    """Eingabe für den Mistral-Large-4-Chat."""

    prompt: str = Field(
        ...,
        description="Frage oder Text, der an Mistral Large 4 geschickt wird.",
    )
    system_prompt: str | None = Field(
        default=None,
        description=(
            "Optionale Vorgabe für Rolle und Stil der Antwort "
            "(wird dem Modell als Anweisung vorangestellt)."
        ),
    )


class ML4ChatOutput(BaseModel):
    """Antwort von Mistral Large 4."""

    answer: str = Field(..., description="Die Antwort des Modells.")
    model: str = Field(..., description="Name des aufgerufenen Modells.")


@workflows.workflow.define(
    name="ml4-chat",
    workflow_display_name="Mistral Large 4 Chat",
    workflow_description=(
        "Sendet eine Eingabe an mistral-large-latest und gibt die Antwort zurück."
    ),
)
class ML4ChatWorkflow:
    @workflows.workflow.entrypoint
    async def run(self, input: ML4ChatInput) -> ML4ChatOutput:
        content = input.prompt
        if input.system_prompt:
            content = f"{input.system_prompt}\n\n---\n\n{input.prompt}"

        request = ChatCompletionRequest(
            model=MODEL,
            messages=[UserMessage(content=content)],
        )
        result = await mistralai_chat_complete(request)
        answer = result.choices[0].message.content or ""

        return ML4ChatOutput(answer=answer, model=MODEL)
